(() => {
  'use strict';
  if (globalThis.__jaTranslatorLoaded) return;
  globalThis.__jaTranslatorLoaded = true;

  const HOST_ID = 'ja-translator-host';
  const SKIP_SELECTOR =
    'script,style,noscript,template,textarea,code,pre,kbd,samp,svg,math,' +
    '[translate="no"],.notranslate,[contenteditable=""],[contenteditable="true"]';
  const CHUNK_CHARS = 4500; // 1 リクエストにまとめる最大文字数（無料枠はリクエスト数が貴重）
  const CHUNK_SEGMENTS = 80;
  const MAX_INFLIGHT = 2;
  // 1 回の翻訳開始で送る文字数の上限。悪意のあるページが文字を生成し続けて、
  // 利用枠を使い切ろうとする（暴走する）のを防ぐ。「再試行」で続きを翻訳できる。
  const MAX_CHARS_PER_RUN = 150000;
  // 1 つの文字ノード（タグで区切られた 1 かたまりの文字）の最大文字数。裏方の上限（20,000）より余裕をもたせる。
  const MAX_NODE_CHARS = 15000;

  // ---------------------------------------------------------------- 状態

  const translated = new Map(); // Text -> { orig, tr }
  const groups = new Map(); // Element -> Set<Text>  画面に入るのを待っているテキスト
  const pending = new Set(); // 画面に入った（翻訳対象になった）Text
  const memo = new Map(); // 原文 -> 訳文（このページ内での重複排除）
  const chunkQueue = [];
  let inflight = 0;
  let state = 'idle'; // 'idle' | 'running' | 'error'
  let active = false;
  let total = 0;
  let done = 0;
  let sentChars = 0;
  let io = null;
  let mo = null;
  let flushTimer = 0;

  // ---------------------------------------------------------------- 翻訳対象の収集

  function isTranslatable(node) {
    const el = node.parentElement;
    if (!el || el.closest(SKIP_SELECTOR) || el.closest('#' + HOST_ID)) return false;
    const t = (node.nodeValue || '').trim();
    if (t.length < 2 || !/\p{L}/u.test(t)) return false;
    // 極端に長い 1 つの文字ノードは対象外にする（裏方の検査で依頼ごと弾かれ、他の文章まで巻き込まないため）
    if (t.length > MAX_NODE_CHARS) return false;
    const kana = (t.match(/[぀-ヿ]/g) || []).length;
    return kana / t.length <= 0.1; // すでに日本語のものは送らない
  }

  function register(root) {
    const nodes = [];
    if (root.nodeType === Node.TEXT_NODE) {
      nodes.push(root);
    } else if (root.nodeType === Node.ELEMENT_NODE) {
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      for (let n = walker.nextNode(); n; n = walker.nextNode()) nodes.push(n);
    }
    for (const node of nodes) {
      if (translated.has(node) || !isTranslatable(node)) continue;
      const el = node.parentElement;
      let set = groups.get(el);
      if (!set) {
        set = new Set();
        groups.set(el, set);
        io.observe(el);
      }
      set.add(node);
    }
  }

  // ---------------------------------------------------------------- 翻訳の実行

  function scheduleFlush() {
    clearTimeout(flushTimer);
    flushTimer = setTimeout(flush, 120);
  }

  function apply(item, tr) {
    const { node, src, lead, trail } = item;
    if (!node.isConnected || node.nodeValue !== src) return; // その間にページ側が書き換えた
    node.nodeValue = lead + tr + trail;
    translated.set(node, { orig: src, tr: node.nodeValue });
  }

  function flush() {
    if (!active) return;
    const bySource = new Map(); // 原文 -> item[]
    // 文の途中でタグ分割された断片が隣り合うよう、文書内の出現順に並べる。
    const ordered = [...pending].sort((a, b) =>
      a === b ? 0 : a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1,
    );
    for (const node of ordered) {
      if (!node.isConnected || translated.has(node)) continue;
      const src = node.nodeValue;
      const core = src.trim();
      const item = {
        node,
        src,
        lead: src.slice(0, src.length - src.trimStart().length),
        trail: src.slice(src.trimEnd().length),
      };
      total++;
      const hit = memo.get(core);
      if (hit) {
        apply(item, hit);
        done++;
        continue;
      }
      if (!bySource.has(core)) bySource.set(core, []);
      bySource.get(core).push(item);
    }
    pending.clear();

    let cores = [];
    let chars = 0;
    const closeChunk = () => {
      if (!cores.length) return;
      chunkQueue.push({ cores, targets: new Map(cores.map((c) => [c, bySource.get(c)])) });
      cores = [];
      chars = 0;
    };
    for (const core of bySource.keys()) {
      if (cores.length && (chars + core.length > CHUNK_CHARS || cores.length >= CHUNK_SEGMENTS)) closeChunk();
      cores.push(core);
      chars += core.length;
    }
    closeChunk();

    pump();
    updateBadge();
  }

  function pump() {
    while (active && inflight < MAX_INFLIGHT && chunkQueue.length) {
      const job = chunkQueue.shift();
      sentChars += job.cores.reduce((sum, c) => sum + c.length, 0);
      if (sentChars > MAX_CHARS_PER_RUN) {
        fail('このページは翻訳する量が多すぎるため、途中で止めました。「再試行」で続きを翻訳できます。');
        return;
      }
      inflight++;
      runJob(job).finally(() => {
        inflight--;
        pump();
        updateBadge();
      });
    }
  }

  async function requestTranslation(texts) {
    try {
      const resp = await chrome.runtime.sendMessage({ type: 'translate', texts });
      return resp || { ok: false, error: '翻訳サービスから応答がありません。' };
    } catch {
      return { ok: false, error: '拡張機能との通信に失敗しました。ページを再読み込みしてください。' };
    }
  }

  async function runJob(job) {
    const resp = await requestTranslation(job.cores);
    if (!active) return;
    if (!resp.ok) {
      if (resp.kind === 'invalid') {
        // この依頼だけが検査で弾かれた（極端な文字列など）。ページ全体の翻訳は止めない。
        // 複数の断片なら、半分ずつに分けて送り直し、問題の断片だけを切り出す。1 つだけなら、その部分を飛ばす。
        if (job.cores.length > 1) {
          const mid = Math.ceil(job.cores.length / 2);
          for (const part of [job.cores.slice(mid), job.cores.slice(0, mid)]) {
            chunkQueue.unshift({ cores: part, targets: new Map(part.map((c) => [c, job.targets.get(c)])) });
          }
          return;
        }
        for (const items of job.targets.values()) done += items.length;
        return;
      }
      fail(resp.error);
      return;
    }
    job.cores.forEach((core, i) => {
      const tr = resp.results[i];
      if (tr) memo.set(core, tr);
      for (const item of job.targets.get(core) || []) {
        if (tr) apply(item, tr);
        done++;
      }
    });
  }

  // ---------------------------------------------------------------- ページ翻訳の開始・停止

  function start() {
    io?.disconnect();
    mo?.disconnect();
    chunkQueue.length = 0;
    groups.clear();
    pending.clear();
    total = 0;
    done = 0;
    sentChars = 0;
    active = true;
    state = 'running';

    io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (!e.isIntersecting) continue;
          io.unobserve(e.target);
          const set = groups.get(e.target);
          groups.delete(e.target);
          if (set) for (const n of set) if (n.isConnected) pending.add(n);
        }
        if (pending.size) scheduleFlush();
      },
      { rootMargin: '1500px 0px 1500px 0px' },
    );

    mo = new MutationObserver((records) => {
      for (const r of records) {
        if (r.type === 'childList') {
          r.addedNodes.forEach((n) => register(n));
        } else if (r.type === 'characterData') {
          const entry = translated.get(r.target);
          if (entry) {
            if (r.target.nodeValue === entry.tr) continue; // 自分の書き換え
            translated.delete(r.target);
          }
          register(r.target);
        }
      }
    });

    register(document.body);
    mo.observe(document.body, { childList: true, subtree: true, characterData: true });

    const titleNode = document.querySelector('title')?.firstChild;
    if (titleNode && titleNode.nodeType === Node.TEXT_NODE && /\p{L}/u.test(titleNode.nodeValue)) {
      pending.add(titleNode);
      scheduleFlush();
    }
    updateBadge();
  }

  function stop() {
    active = false;
    state = 'idle';
    io?.disconnect();
    mo?.disconnect();
    clearTimeout(flushTimer);
    chunkQueue.length = 0;
    groups.clear();
    pending.clear();
    for (const [node, entry] of translated) {
      if (node.isConnected && node.nodeValue === entry.tr) node.nodeValue = entry.orig;
    }
    translated.clear();
    removeBadge();
  }

  function fail(message) {
    if (state === 'error') return;
    state = 'error';
    active = false;
    io?.disconnect();
    mo?.disconnect();
    clearTimeout(flushTimer);
    chunkQueue.length = 0;
    groups.clear();
    pending.clear();
    setBadge(message, true, [
      { label: '再試行', onClick: start },
      { label: '原文に戻す', onClick: stop },
    ]);
  }

  function togglePage() {
    if (state === 'running') stop();
    else start(); // 'idle' または 'error'（再試行）
  }

  function updateBadge() {
    if (state !== 'running') return;
    const busy = chunkQueue.length > 0 || inflight > 0 || pending.size > 0;
    let text;
    if (busy) text = `翻訳中… ${done}/${total}`;
    else text = groups.size > 0 ? '日本語に翻訳済み（スクロールで続きも翻訳します）' : '日本語に翻訳済み';
    setBadge(text, false, [{ label: '原文に戻す', onClick: stop }]);
  }

  // ---------------------------------------------------------------- UI（Shadow DOM でページの CSS から隔離）

  const CSS = `
    :host { all: initial; }
    .badge, .panel {
      position: fixed; pointer-events: auto; box-sizing: border-box;
      font: 13px/1.5 system-ui, "Yu Gothic UI", "Meiryo", sans-serif;
      color: #1f2328; background: #fff; border: 1px solid #d0d7de; border-radius: 10px;
      box-shadow: 0 6px 24px rgba(0, 0, 0, .18);
    }
    .badge { right: 16px; bottom: 16px; padding: 8px 12px; display: flex; gap: 10px; align-items: center;
      max-width: min(440px, calc(100vw - 32px)); }
    .badge.error { border-color: #cf222e; }
    .badge .msg { flex: 1; }
    .panel { width: min(420px, calc(100vw - 32px)); max-height: 60vh; display: flex; flex-direction: column; }
    .panel .body { padding: 12px 14px; overflow: auto; white-space: pre-wrap; word-break: break-word; }
    .panel .body.error { color: #cf222e; }
    .panel .bar { display: flex; gap: 6px; justify-content: flex-end; padding: 6px 8px; border-top: 1px solid #d0d7de; }
    button { font: inherit; color: inherit; background: #f6f8fa; border: 1px solid #d0d7de; border-radius: 6px;
      padding: 2px 10px; cursor: pointer; white-space: nowrap; }
    button:hover { background: #eaeef2; }
    @media (prefers-color-scheme: dark) {
      .badge, .panel { color: #e6edf3; background: #161b22; border-color: #30363d; }
      .badge.error { border-color: #f85149; }
      .panel .body.error { color: #ff7b72; }
      .panel .bar { border-top-color: #30363d; }
      button { background: #21262d; border-color: #30363d; }
      button:hover { background: #30363d; }
    }`;

  let host = null;
  let shadow = null;
  let badgeEl = null;
  let panelEl = null;

  function ensureUi() {
    if (host && host.isConnected) return;
    badgeEl = null;
    panelEl = null;
    host = document.createElement('div');
    host.id = HOST_ID;
    host.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;';
    shadow = host.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = CSS;
    shadow.append(style);
    document.documentElement.append(host);
  }

  function makeButton(label, onClick) {
    const b = document.createElement('button');
    b.textContent = label;
    b.addEventListener('click', onClick);
    return b;
  }

  function setBadge(text, isError, actions) {
    ensureUi();
    if (!badgeEl) {
      badgeEl = document.createElement('div');
      shadow.append(badgeEl);
    }
    badgeEl.className = 'badge' + (isError ? ' error' : '');
    const msg = document.createElement('span');
    msg.className = 'msg';
    msg.textContent = text;
    badgeEl.replaceChildren(msg, ...actions.map((a) => makeButton(a.label, a.onClick)));
  }

  function removeBadge() {
    badgeEl?.remove();
    badgeEl = null;
  }

  // ---------------------------------------------------------------- 選択範囲の翻訳

  function selectionRect() {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0 || sel.isCollapsed) return null;
    const r = sel.getRangeAt(0).getBoundingClientRect();
    return r.width || r.height ? r : null;
  }

  const onKeyDown = (e) => {
    if (e.key === 'Escape') closePanel();
  };
  const onPointerDown = (e) => {
    if (!e.composedPath().includes(host)) closePanel();
  };

  function closePanel() {
    panelEl?.remove();
    panelEl = null;
    document.removeEventListener('keydown', onKeyDown, true);
    document.removeEventListener('pointerdown', onPointerDown, true);
  }

  function openPanel(rect) {
    closePanel();
    ensureUi();
    const el = document.createElement('div');
    el.className = 'panel';
    const body = document.createElement('div');
    body.className = 'body';
    const bar = document.createElement('div');
    bar.className = 'bar';
    const copyBtn = makeButton('コピー', () => {
      navigator.clipboard?.writeText(body.textContent).catch(() => {});
    });
    bar.append(copyBtn, makeButton('閉じる', closePanel));
    el.append(body, bar);
    shadow.append(el);

    const width = Math.min(420, window.innerWidth - 32);
    if (rect) {
      el.style.left = Math.max(16, Math.min(rect.left, window.innerWidth - width - 16)) + 'px';
      if (rect.bottom + 140 > window.innerHeight && rect.top > 180) {
        el.style.bottom = window.innerHeight - rect.top + 8 + 'px';
      } else {
        el.style.top = rect.bottom + 8 + 'px';
      }
    } else {
      el.style.top = '16px';
      el.style.right = '16px';
    }

    document.addEventListener('keydown', onKeyDown, true);
    document.addEventListener('pointerdown', onPointerDown, true);
    panelEl = el;
    return {
      el,
      setBody(text, isError = false) {
        body.textContent = text;
        body.className = 'body' + (isError ? ' error' : '');
      },
    };
  }

  async function translateSelection(text) {
    const source = (text || window.getSelection()?.toString() || '').trim();
    if (!source) return;
    const panel = openPanel(selectionRect());
    panel.setBody('翻訳中…');
    const resp = await requestTranslation([source]);
    if (panelEl !== panel.el) return; // 閉じられた
    if (!resp.ok) panel.setBody(resp.error, true);
    else if (!resp.results[0]) panel.setBody('翻訳結果を取得できませんでした。', true);
    else panel.setBody(resp.results[0]);
  }

  // ---------------------------------------------------------------- メッセージ受信

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    switch (msg?.type) {
      case 'ping':
        sendResponse(true);
        break;
      case 'toggle-page':
        togglePage();
        break;
      case 'translate-selection':
        translateSelection(msg.text);
        break;
    }
  });
})();
