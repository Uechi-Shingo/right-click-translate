'use strict';

const DEFAULTS = {
  apiKey: '',
  model: 'gemini-3.5-flash-lite',
  fallbackModel: 'gemini-3.8-flash',
  useCache: true,
  rememberKey: true,
  acknowledged: false,
};

// Google から一覧を取得できないとき（キー未設定・オフライン）に出す候補
const FALLBACK_MODELS = [
  'gemini-3.8-flash',
  'gemini-3.6-flash',
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite',
];
const CUSTOM = '__custom__';

const $ = (id) => document.getElementById(id);
const statusEl = $('status');
const fields = {
  model: { select: $('model'), custom: $('modelCustom'), allowNone: false },
  fallbackModel: { select: $('fallbackModel'), custom: $('fallbackCustom'), allowNone: true },
};
let modelIds = FALLBACK_MODELS;

function setStatus(text, kind = '') {
  statusEl.textContent = text;
  statusEl.className = kind;
}

function describe(id) {
  if (/flash-lite/.test(id)) return '軽量・低コスト';
  if (/flash/.test(id)) return '標準・高品質';
  if (/pro/.test(id)) return '高性能（無料枠がない場合あり）';
  return '';
}

function fillSelect({ select, custom, allowNone }, value) {
  select.replaceChildren();
  if (allowNone) select.append(new Option('（予備モデルを使わない）', ''));
  const ids = [...modelIds];
  if (value && !ids.includes(value)) ids.unshift(value); // 保存済みの値が一覧になくても選べるように
  for (const id of ids) {
    const note = describe(id);
    select.append(new Option(note ? `${id}　${note}` : id, id));
  }
  select.append(new Option('その他（モデル名を手入力）', CUSTOM));
  select.value = value;
  custom.hidden = true;
}

function readValue({ select, custom }) {
  return select.value === CUSTOM ? custom.value.trim() : select.value;
}

for (const f of Object.values(fields)) {
  f.select.addEventListener('change', () => {
    f.custom.hidden = f.select.value !== CUSTOM;
    if (!f.custom.hidden) f.custom.focus();
  });
}

async function load() {
  const s = await chrome.storage.local.get({ ...DEFAULTS, modelList: null });
  if (Array.isArray(s.modelList) && s.modelList.length) modelIds = s.modelList;
  // 「ブラウザを閉じたら忘れる」モードのキーは storage.session にある
  const apiKey = s.rememberKey ? s.apiKey : (await chrome.storage.session.get({ apiKey: '' })).apiKey;
  $('apiKey').value = apiKey;
  $('rememberKey').checked = s.rememberKey;
  $('acknowledged').checked = s.acknowledged;
  fillSelect(fields.model, s.model);
  fillSelect(fields.fallbackModel, s.fallbackModel);
  $('useCache').checked = s.useCache;
  $('modelNote').textContent = Array.isArray(s.modelList)
    ? `Google から取得した ${modelIds.length} 件を表示中`
    : '既定の候補を表示中（キーを保存して「モデル一覧を更新」で最新を取得できます）';
  if (apiKey) refreshModels({ saveFirst: false, quiet: true });
}

async function save() {
  const apiKey = $('apiKey').value.trim();
  const remember = $('rememberKey').checked;
  await chrome.storage.local.set({
    // 「忘れる」モードでは、キーをディスク上の保存領域に書かない
    apiKey: remember ? apiKey : '',
    rememberKey: remember,
    acknowledged: $('acknowledged').checked,
    model: readValue(fields.model) || DEFAULTS.model,
    fallbackModel: readValue(fields.fallbackModel),
    useCache: $('useCache').checked,
  });
  if (remember) await chrome.storage.session.remove('apiKey');
  else await chrome.storage.session.set({ apiKey });
}

async function refreshModels({ saveFirst, quiet }) {
  if (!$('apiKey').value.trim()) {
    if (!quiet) setStatus('先に APIキーを入力してください。', 'err');
    return;
  }
  const button = $('refreshModels');
  button.disabled = true;
  $('modelNote').textContent = '取得中…';
  try {
    if (saveFirst) await save(); // 一覧の取得は保存済みのキーを使う
    const resp = await chrome.runtime.sendMessage({ type: 'list-models' });
    if (resp?.ok && resp.models.length) {
      const keep = { model: readValue(fields.model), fallbackModel: readValue(fields.fallbackModel) };
      modelIds = resp.models.map((m) => m.id);
      await chrome.storage.local.set({ modelList: modelIds });
      fillSelect(fields.model, keep.model);
      fillSelect(fields.fallbackModel, keep.fallbackModel);
      const unavailable = [keep.model, keep.fallbackModel].filter((m) => m && !modelIds.includes(m));
      $('modelNote').textContent = `Google から取得した ${modelIds.length} 件を表示中` +
        (unavailable.length ? `（注意: 選択中の ${unavailable.join('、')} は、このキーの一覧にありません。使えない可能性があります）` : '');
    } else if (resp?.ok) {
      $('modelNote').textContent = '使えるモデルが見つかりませんでした（既定の候補を表示中）';
    } else {
      $('modelNote').textContent = `一覧を取得できませんでした: ${resp?.error || '応答がありません。'}`;
    }
  } finally {
    button.disabled = false;
  }
}

$('save').addEventListener('click', async () => {
  await save();
  if (!$('acknowledged').checked) setStatus('保存しました。翻訳を使うには「上記を理解しました」にチェックを入れて、もう一度保存してください。', 'err');
  else setStatus('保存しました。', 'ok');
});

$('refreshModels').addEventListener('click', () => refreshModels({ saveFirst: true, quiet: false }));

$('test').addEventListener('click', async () => {
  await save();
  if (!$('apiKey').value.trim()) {
    setStatus('APIキーを入力してください。', 'err');
    return;
  }
  const startedAt = Date.now();
  const tick = () => setStatus(`テスト中… ${Math.floor((Date.now() - startedAt) / 1000)} 秒経過`);
  tick();
  const timer = setInterval(tick, 500);
  let resp;
  try {
    resp = await chrome.runtime.sendMessage({
      type: 'translate',
      noCache: true,
      texts: ['Hello! This is a connection test for the translation extension.'],
    });
  } finally {
    clearInterval(timer);
  }
  const detail = describeTiming(resp?.meta, Date.now() - startedAt);
  if (resp?.ok && resp.results[0]) setStatus(`成功しました:\n${resp.results[0]}\n\n${detail}`, 'ok');
  else setStatus(`失敗しました:\n${resp?.error || '応答がありません。'}\n\n${detail}`, 'err');
});

// 接続テストの所要時間の内訳。「Google 側が遅いのか、拡張機能側の待機なのか」を判断するための情報。
function describeTiming(meta, measuredMs) {
  const sec = (ms) => `${(ms / 1000).toFixed(1)} 秒`;
  if (!meta) return `所要時間: ${sec(measuredMs)}`;
  const attemptLabel = (s) => (s === 'timeout' ? 'タイムアウト' : s === 'network' ? '通信失敗' : s === 200 ? '成功' : `HTTP ${s}`);
  const lines = [
    `所要時間: ${sec(meta.totalMs)}（Google の応答待ち ${sec(meta.apiMs)} ／ 再試行のための待機 ${sec(meta.waitedMs)}）`,
    `Google への依頼: ${meta.requests} 回 ／ モデル: ${meta.model || '（成功なし）'}`,
  ];
  if (meta.attempts?.length) {
    lines.push(`依頼ごとの結果: ${meta.attempts.map((a, i) => `${i + 1} 回目 ${a.model} → ${attemptLabel(a.status)}（${sec(a.ms)}${a.serverMs != null ? `、うち Google サーバー処理 ${sec(a.serverMs)}` : ''}）`).join(' ／ ')}`);
  }
  const t = meta.tokens;
  if (t && (t.prompt || t.output || t.thoughts)) {
    lines.push(`トークン数: 入力 ${t.prompt} ／ 出力 ${t.output} ／ 思考 ${t.thoughts}`);
  }

  const timedOut = meta.attempts?.some((a) => a.status === 'timeout');
  if (timedOut) {
    lines.push('→ Google の応答が遅かったため、待つのをやめて別のモデルに切り替えました。');
  } else if (meta.waitedMs >= 1000) {
    lines.push('→ 無料枠の回数制限やサーバーの一時的なエラーのため、再試行の待機が発生していました。');
  } else if (meta.apiMs >= 8000) {
    const last = meta.attempts?.[meta.attempts.length - 1];
    if (t && t.thoughts >= 300) {
      lines.push('→ モデルの「思考」に時間を使っています（思考のトークン数が多い）。思考の少ない Flash-Lite 系のモデルで速くなることがあります。');
    } else if (last?.serverMs != null && last.serverMs >= last.ms * 0.8) {
      lines.push('→ 時間の大半は、Google のサーバー内での待ち・処理です（混雑など）。思考のトークン数は多くないため、モデルの思考は原因ではありません。拡張機能やネットワークの問題ではありません。');
    } else if (last?.serverMs != null) {
      lines.push(`→ Google のサーバー処理は ${sec(last.serverMs)} と短いのに、全体では ${sec(last.ms)} かかっています。Google の手前（ブラウザ・ネットワーク・セキュリティソフト等）の経路に原因がある可能性があります。`);
    } else {
      lines.push('→ Google の応答待ちに時間がかかっています（混雑など）。思考のトークン数は多くないため、モデルの思考は原因ではありません。');
    }
  } else {
    lines.push('→ 正常です。待機や再試行はありませんでした。');
  }
  return lines.join('\n');
}

// 応答速度の診断。複数のモデルに短い依頼を同時に送り、「どのモデルが速いか」「依頼内容だけが遅いのか」を調べる。
$('probe').addEventListener('click', async () => {
  await save();
  if (!$('apiKey').value.trim()) {
    setStatus('APIキーを入力してください。', 'err');
    return;
  }
  const primary = readValue(fields.model);
  const backup = readValue(fields.fallbackModel);
  // 主モデル・予備モデルに、一覧にある軽量（Flash-Lite）系を優先して足し、最大 4 つ測る
  const others = [...modelIds].sort((a, b) => Number(/flash-lite/.test(b)) - Number(/flash-lite/.test(a)));
  const models = [...new Set([primary, backup, ...others].filter(Boolean))].slice(0, 4);

  const startedAt = Date.now();
  const tick = () => setStatus(`診断中… ${Math.floor((Date.now() - startedAt) / 1000)} 秒経過（最大 2〜3 分かかります）\n対象: ${models.join(' ／ ')}`);
  tick();
  const timer = setInterval(tick, 500);
  let resp;
  try {
    resp = await chrome.runtime.sendMessage({ type: 'probe', models });
  } finally {
    clearInterval(timer);
  }
  if (resp?.ok) setStatus(describeProbe(resp.results, primary), 'ok');
  else setStatus(`診断に失敗しました:\n${resp?.error || '応答がありません。'}`, 'err');
});

function describeProbe(results, primary) {
  const sec = (ms) => `${(ms / 1000).toFixed(1)} 秒`;
  const FAST_MS = 10000;
  const kind = (r) => (r.label === 'same' ? '拡張機能の翻訳依頼と同じ内容' : '短い依頼');
  const lines = ['応答速度の診断結果（同時に測定）:'];
  for (const r of results) {
    const timing = `全体 ${sec(r.ms)}${r.serverMs != null ? ` ／ Google サーバー処理 ${sec(r.serverMs)}` : ''}`;
    lines.push(`  ${r.model} ／ ${kind(r)} → ${r.ok ? '成功' : `失敗（${r.error}）`} ／ ${timing}`);
  }
  lines.push('');

  const shorts = results.filter((r) => r.label === 'short' && r.ok);
  const same = results.find((r) => r.label === 'same');
  const fast = shorts.filter((r) => r.ms < FAST_MS).sort((a, b) => a.ms - b.ms);
  const primaryShort = shorts.find((r) => r.model === primary);

  if (!shorts.length) {
    lines.push('→ すべて失敗しました。上のエラー内容を確認してください。');
  } else if (!fast.length) {
    lines.push('→ どのモデルも 10 秒以上かかっています。Google 側の全体的な混雑の可能性が高く、拡張機能では改善できません。時間を置いて試してください。');
  } else if (primaryShort && primaryShort.ms >= FAST_MS) {
    lines.push(`→ 速いモデルがあります: ${fast[0].model}（${sec(fast[0].ms)}）。主モデルをこれに変えると改善する見込みです。`);
  } else {
    lines.push('→ 主モデルは短い依頼には速く応答しています。');
    if (same && same.ok && same.ms >= FAST_MS) {
      lines.push('   ただし、拡張機能の翻訳依頼と同じ内容だけが遅くなっています。依頼内容に起因する可能性があります。');
    }
  }
  return lines.join('\n');
}

$('clearCache').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'clear-cache' });
  setStatus('キャッシュを削除しました。', 'ok');
});

$('deleteKey').addEventListener('click', async () => {
  $('apiKey').value = '';
  await chrome.storage.local.set({ apiKey: '' });
  await chrome.storage.session.remove('apiKey');
  setStatus('APIキーを削除しました。このブラウザには、もうキーが残っていません。', 'ok');
});

load();
